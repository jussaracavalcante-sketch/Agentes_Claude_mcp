# Mapa de Conectores

## Status de autenticação

| Conector | Tipo | Modo | Agentes | Criticidade |
|---|---|---|---|---|
| **Google Ads MCP** (MCC Vanguarda) | Proprietário | **Somente leitura** | AGT-07, 08, 09 | **Crítica** |
| **Meta Ads Vanguarda** | Proprietário | Leitura | AGT-07, 08, 09 | **Crítica** |
| HubSpot | Padrão | Leitura + staging | AGT-01, 05, 06, 09, 10 | **Crítica** |
| RD Station | Padrão | Leitura + staging | AGT-06, 09 | Alta |
| Semrush | Padrão | Leitura | AGT-01, 02, 03 | Média |
| Canva | Padrão | Escrita (design) | AGT-05 | Alta |
| Supabase | Padrão | Leitura + escrita | AGT-08, 15, 16 | Alta |
| Asana / monday / Jira / Linear | Padrão | Leitura + escrita | AGT-00, 11, 12 | Alta |
| Google Calendar / Gmail / Drive | Padrão | Leitura | AGT-00, 02, 09, 12, 14 | Média |
| Notion | Padrão | Leitura + escrita | AGT-00, 03, 04, 11, 13 | Média |
| Intercom | Padrão | Leitura | AGT-04, 16 | Média |
| Figma / Miro / Lovable | Padrão | Leitura | AGT-03, 05, 16 | Baixa |
| **iClips / Conexa (ERP)** | — | ⚠ **NÃO CONECTADO** | AGT-06, 10, 15 | **BLOQUEIA** |

## Nota sobre o Google Ads MCP
Conector proprietário com auto-discovery de carteira via `listar_clientes` — conta nova
no MCC entra na varredura sem cadastro manual de ID. `query_gaql` aceita **apenas
SELECT**, o que torna o AGT-07 estruturalmente incapaz de alterar conta. É por isso que
o piloto começa por mídia: alto valor, risco baixo por desenho.

## Nota sobre iClips / Conexa
Ausência de conector financeiro é o **bloqueio de maior impacto do programa**.
Ver `runbooks/mapeamento-fonte-financeira.md`.

## Regra de degradação
Conector fora do ar não degrada para estimativa. Degrada para **parada com reporte**.
Ver `runbooks/connector-failure.md` e Gate G4.
