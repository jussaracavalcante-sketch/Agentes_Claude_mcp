# Runbook — Falha de Conector

## Princípio
**Conector fora do ar = parada.** Nunca completar lacuna com estimativa, média
histórica ou "aproximadamente". Em relatório de cliente isso é falha de confiança
irreversível. Ver Gate G4.

## Procedimento
1. **Identificar** qual conector falhou. Nomear explicitamente na mensagem ao usuário.
2. **Classificar** a falha:
   | Tipo | Sintoma | Ação |
   |---|---|---|
   | Autenticação | 401/403 | Reautenticar o conector nas configurações |
   | Permissão | 403 com escopo | Pedir liberação ao admin da conta |
   | Indisponibilidade | 5xx / timeout | Aguardar e repetir; verificar status do fornecedor |
   | Limite de taxa | 429 | Repetir com espera progressiva |
3. **Perguntar** ao usuário: repetir ou abortar. Não decidir sozinho.
4. **Registrar** em `governance/incidentes.log`: data, agente, conector, tipo, duração.

## Impacto por conector

| Conector | Agentes bloqueados | Fallback manual |
|---|---|---|
| Google Ads MCP | AGT-07, AGT-09 | Export CSV da interface do Ads |
| Meta Ads | AGT-07, AGT-09 | Export do Gerenciador de Anúncios |
| HubSpot | AGT-01, 05, 06, 09, 10 | Export CSV de contatos e campanhas |
| Canva | AGT-05 | Produção manual no Canva |
| Asana/monday/Jira | AGT-11, AGT-12 | Leitura direta na ferramenta |
| Supabase | AGT-08, AGT-15 | Query direta no banco |

## Health-check diário
Antes da rotina das 08h, validar autenticação de todos os conectores das rotinas
automáticas (AGT-00, AGT-07, AGT-12). Falha detectada aqui evita rotina parcial.
