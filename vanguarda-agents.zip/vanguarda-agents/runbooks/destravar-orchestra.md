# Runbook — Destravar o AGT-10 ORCHESTRA

**Status do bloqueio:** ATIVO · **Dono da decisão:** COO · **Prazo:** D+15

## Diagnóstico
A skill `run-campaign` invoca duas skills ausentes do inventário instalado:
- `content-strategy` — usada nos Passos 1 e 2 (análise de vendas e brief)
- `lead-triage` — usada no Passo 3 (segmentação e lista de call)

Bloqueio adicional herdado: fonte financeira (QuickBooks/PayPal vs. iClips/Conexa).

## Opção A — Implementar as skills ausentes
**Esforço:** alto · **Prazo:** 3–4 semanas
Criar `content-strategy` e `lead-triage` via `skill-creator` (disponível no AGT-00).
- Prós: preserva o pipeline original sem reescrita
- Contras: duas skills novas para manter; ainda exige resolver a fonte financeira

## Opção B — Redesenhar usando agentes existentes ✅ recomendada
**Esforço:** médio · **Prazo:** 1–2 semanas
Reescrever o encadeamento como `AGT-06 → AGT-05 → AGT-01`, todos já mapeados.
- Prós: usa ativo existente; menos superfície de manutenção; destrava mais rápido
- Contras: exige reescrever a skill `run-campaign`
- **Pré-requisito:** ainda depende de resolver a fonte financeira do AGT-06

## Opção C — Pipeline degradado sem análise de vendas
**Esforço:** baixo · **Prazo:** dias
Começar o pipeline no brief (AGT-03), pulando a análise de vendas.
- Prós: destrava imediatamente e não depende de fonte financeira
- Contras: perde o diferencial de conteúdo orientado a dado de venda

## Recomendação
**B como destino, C como ponte.** Rodar C para gerar aprendizado operacional e
evidência de valor enquanto B é construído. Não esperar a solução completa para
começar a aprender.

## Critério de saída
- [ ] Pipeline roda ponta a ponta em ambiente de teste
- [ ] Os 3 gates funcionam (testar tentativa de pular gate — deve recusar)
- [ ] Fonte financeira resolvida ou escopo ajustado formalmente
- [ ] Ficha de homologação preenchida
