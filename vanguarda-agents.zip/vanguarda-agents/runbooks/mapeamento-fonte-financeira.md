# Runbook — Mapeamento de Fonte Financeira

**Status:** ATIVO · **Dono:** CFO (Wilson Caldas Jr.) · **Bloqueia:** AGT-06, AGT-10, AGT-15

## Diagnóstico
As skills `sales-brief` e `run-campaign` presumem **QuickBooks** e **PayPal**.
O ecossistema Vanguarda opera com:

| Entidade | ERP | CNPJ |
|---|---|---|
| Vanguarda Martech | iClips | 07.865.616/0001-74 |
| VPromo | iClips | 07.865.616/0001-74 |
| VBOT | Conexa | 61.077.352/0001-30 |

Enquanto isso não for resolvido, qualquer agente que dependa de receita real
produz número errado ou não roda.

## Opções

| # | Abordagem | Esforço | Latência do dado | Recomendação |
|---|---|---|---|---|
| A | API iClips/Conexa → Supabase; agentes leem do Supabase | Alto | Near real-time | **Destino** |
| B | Export mensal `.xlsx` ingerido manualmente | Baixo | Mensal | **Ponte** |
| C | Reescrever as skills para ler direto do ERP | Médio | Real-time | Só se A for inviável |

## Perguntas a responder antes de decidir
1. iClips e Conexa expõem API pública? Qual autenticação e limite de taxa?
2. Existe granularidade por **item/serviço**, ou só por nota fiscal? Sem granularidade
   de item, o `sales-brief` não consegue ranquear produto — muda o escopo do AGT-06.
3. Há campo de **margem** ou apenas receita? Sem margem, o AGT-15 fica incompleto.
4. As duas entidades consolidam em visão única, ou o dashboard é por CNPJ?
5. Quem é o dono do dado financeiro e aprova o acesso do agente?

> **A pergunta 2 é a mais crítica.** Se o ERP não der granularidade de item,
> o AGT-06 precisa ser reescopado antes de qualquer desenvolvimento.

## Critério de saída
- [ ] Fonte definida e acesso liberado
- [ ] Granularidade validada (item, período, margem)
- [ ] Amostra reconciliada contra fechamento contábil de um mês
- [ ] Skills `sales-brief` / `run-campaign` atualizadas para a fonte real
