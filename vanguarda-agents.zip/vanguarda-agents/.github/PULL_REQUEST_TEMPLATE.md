## O que muda

## Agente(s) afetado(s)
`AGT-__`

## Checklist
- [ ] Frontmatter completo (`name`, `agent-id`, `layer`, `autonomy`, `status`, `owner`, `composes`)
- [ ] `python3 validate.py` passa localmente
- [ ] `python3 build-catalog.py` rodado e `CATALOG.md` commitado
- [ ] Seção "Falhas conhecidas" preenchida com conteúdo real
- [ ] Nenhuma credencial, dado pessoal ou dado financeiro real adicionado
- [ ] Se mudou autonomia: **aprovação do COO obtida**
- [ ] Se mudou gate: **decisão do Comitê registrada em ata**

## Aprovação
- Dono do agente: @
- COO (se autonomia ou gate): @
