---
name: Proposta de novo agente
about: Propor um agente para o portfolio
labels: novo-agente
---

## Dor operacional
Qual trabalho repetitivo este agente elimina? Uma frase.
*Se não couber em uma frase, o escopo está errado.*

## Quanto custa hoje
- Horas/mês gastas hoje: ____ h  ( ) medido  ( ) estimado
- Quem executa: ____
- **Se estimado, medir antes de abrir esta issue.** Ver `metrics/baseline.md`.

## Desenho proposto
- **Camada:** 0 Orquestração / 1 Front Office / 2 Delivery / 3 Inteligência / 4 Governança
- **Autonomia:** N1 / N2 / N3  *(N4 vedado)*
- **Dono proposto:**
- **Skills que compõe:**
- **Conectores necessários:**

## Gates
Quais aprovações são obrigatórias? Coerente com `governance/approval-gates.md`?

## Como saber se funcionou
2 a 4 KPIs com meta. Sem métrica, o agente não entra em produção.

## Riscos
O que pode dar errado? Trata dado pessoal? Se sim, base legal mapeada?
