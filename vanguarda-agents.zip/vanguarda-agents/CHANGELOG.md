# Changelog

Formato: [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/) · SemVer.

## [1.0.0] — 2026-08-07

### Adicionado
- Repositório inicial com 17 agentes (AGT-00 a AGT-16) em 5 camadas
- Política de níveis de autonomia (N1–N3; N4 vedado)
- Cinco gates de aprovação inegociáveis (G1–G5)
- Registro de riscos com 12 entradas, 5 ativas
- Template LGPD por conector (não preenchido — bloqueante)
- Template de agente e ficha de homologação
- Três runbooks: falha de conector, destravar Orchestra, fonte financeira
- Instrumento de baseline e OKR do programa

### Bloqueios identificados na criação
- `content-strategy` e `lead-triage` ausentes → AGT-10 marcado `bloqueado`
- `change-management` vazia (só link externo) → AGT-14 marcado `bloqueado`
- Fonte financeira QuickBooks/PayPal ≠ iClips/Conexa → AGT-06 marcado `bloqueado`

### Pendências de decisão
- Organograma real para fechar os donos do RACI
- Destino do AGT-10: implementar skills ausentes ou redesenhar
- Escopo por entidade: programa unificado ou recorte por CNPJ
