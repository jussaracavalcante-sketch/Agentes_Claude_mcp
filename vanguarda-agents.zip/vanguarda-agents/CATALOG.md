# Catálogo de Agentes

> Gerado por `build-catalog.py`. **Não editar à mão** — editar o frontmatter do agente e regerar.

**17 agentes** · ⚪ Backlog: 7 · 🔵 Piloto: 5 · 🔴 BLOQUEADO: 3 · 🟢 Produção: 1 · 🟡 Homologação: 1

| ID | Agente | Camada | Autonomia | Status | Dono | Skills |
|---|---|---|---|---|---|---|
| [`AGT-00`](agents/AGT-00-coo-copilot/AGENT.md) | COO COPILOT | Orquestração | N3 | 🟢 Produção | COO | 6 |
| [`AGT-01`](agents/AGT-01-prospector/AGENT.md) | PROSPECTOR | Front Office | N3 | 🟡 Homologação | Diretoria de Novos Negócios | 1 |
| [`AGT-02`](agents/AGT-02-pitch/AGENT.md) | PITCH | Front Office | N2 | ⚪ Backlog | Diretoria de Novos Negócios | 4 |
| [`AGT-03`](agents/AGT-03-strategos/AGENT.md) | STRATEGOS | Front Office | N2 | ⚪ Backlog | Diretoria de Planejamento | 2 |
| [`AGT-04`](agents/AGT-04-insight/AGENT.md) | INSIGHT | Front Office | N3 | ⚪ Backlog | Diretoria de Planejamento | 1 |
| [`AGT-05`](agents/AGT-05-studio/AGENT.md) | STUDIO | Delivery | N2 | ⚪ Backlog | Diretoria de Criação | 2 |
| [`AGT-06`](agents/AGT-06-content/AGENT.md) | CONTENT | Delivery | N2 | 🔴 BLOQUEADO | Diretoria de Planejamento | 1 |
| [`AGT-07`](agents/AGT-07-media-ops/AGENT.md) | MEDIA OPS | Delivery | N1 | 🔵 Piloto | Head de Mídia | 3 |
| [`AGT-08`](agents/AGT-08-analytics/AGENT.md) | ANALYTICS | Inteligência | N3 | 🔵 Piloto | Head de Dados | 9 |
| [`AGT-09`](agents/AGT-09-report/AGENT.md) | REPORT | Inteligência | N2 | 🔵 Piloto | Diretoria de Atendimento | 5 |
| [`AGT-10`](agents/AGT-10-orchestra/AGENT.md) | ORCHESTRA | Orquestração | N2 | 🔴 BLOQUEADO | COO | 1 |
| [`AGT-11`](agents/AGT-11-pmo/AGENT.md) | PMO | Governança & Backoffice | N2 | ⚪ Backlog | COO | 3 |
| [`AGT-12`](agents/AGT-12-traffic/AGENT.md) | TRAFFIC | Governança & Backoffice | N3 | 🔵 Piloto | COO | 2 |
| [`AGT-13`](agents/AGT-13-qualis/AGENT.md) | QUALIS | Governança & Backoffice | N2 | 🔵 Piloto | CFO — Wilson Caldas Jr. | 2 |
| [`AGT-14`](agents/AGT-14-change/AGENT.md) | CHANGE | Inteligência | N2 | 🔴 BLOQUEADO | COO | 2 |
| [`AGT-15`](agents/AGT-15-value/AGENT.md) | VALUE | Governança & Backoffice | N1 | ⚪ Backlog | CFO | 3 |
| [`AGT-16`](agents/AGT-16-vbot/AGENT.md) | VBOT | Governança & Backoffice | N2 | ⚪ Backlog | Head de Produto | 2 |

## 🔴 Agentes bloqueados — não vão a produção

| ID | Agente | Bloqueio | Runbook |
|---|---|---|---|
| `AGT-06` | CONTENT | `fonte-financeira-nao-mapeada` | runbooks/mapeamento-fonte-financeira.md |
| `AGT-10` | ORCHESTRA | `[skill-content-strategy-ausente, skill-lead-triage-ausente, fonte-financeira-nao-mapeada]` | runbooks/destravar-orchestra.md |
| `AGT-14` | CHANGE | `skill-change-management-vazia` | — |

## Distribuição por camada

| Camada | Agentes |
|---|---|
| 0 — Orquestração | AGT-00 · AGT-10 |
| 1 — Front Office | AGT-01 · AGT-02 · AGT-03 · AGT-04 |
| 2 — Delivery | AGT-05 · AGT-06 · AGT-07 |
| 3 — Inteligência | AGT-08 · AGT-09 · AGT-14 |
| 4 — Governança & Backoffice | AGT-11 · AGT-12 · AGT-13 · AGT-15 · AGT-16 |
