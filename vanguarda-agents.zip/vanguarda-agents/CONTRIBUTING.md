# Como contribuir

Este repositório governa agentes que operam sobre dado de cliente e sobre a marca.
As regras abaixo não são estilo — são controle de risco.

## Regras de entrada

Nenhum agente muda de status sem:

1. **Dono nomeado** no frontmatter (`owner`) — é o **A** do RACI
2. **Nível de autonomia** declarado (`autonomy`) — **N4 é vedado**
3. **Gates** coerentes com `governance/approval-gates.md`
4. **KPI mensurável** — sem métrica, não vai a produção
5. **Seção "Falhas conhecidas"** com conteúdo real — agente sem falha declarada é agente não testado
6. **Ficha de homologação** assinada (`templates/ficha-homologacao.md`)

A CI (`.github/workflows/validate-agents.yml`) verifica automaticamente os itens 1, 2 e 5.

## Fluxo

```
branch  →  editar AGENT.md  →  python3 build-catalog.py  →  PR  →  review do dono  →  merge
```

- **Nunca editar `CATALOG.md` à mão.** É gerado. Editar o frontmatter e regerar.
- Branch: `agente/AGT-XX-descricao` ou `governanca/descricao`
- Commit: [Conventional Commits](https://www.conventionalcommits.org/pt-br/)
  - `feat(AGT-07): adiciona varredura de pacing`
  - `fix(AGT-09): corrige ordem de validacao`
  - `docs(governance): atualiza mapa LGPD`

## Review obrigatório

| Mudança | Quem aprova |
|---|---|
| Conteúdo de agente | Dono do agente (`owner`) |
| Nível de autonomia | Dono **e** COO |
| Gates (`governance/approval-gates.md`) | Comitê Executivo, com ata |
| Mapa LGPD | DPO / Jurídico |

## O que NUNCA entra neste repositório

- Token, chave ou credencial de qualquer tipo
- Dado pessoal de cliente ou colaborador
- Dado financeiro real (receita, margem, custo por cliente)
- Nome ou identificador de cliente em exemplo

> Este repositório versiona **estrutura e método**. Dado operacional vive nos sistemas
> de origem, sob os controles de acesso deles.
