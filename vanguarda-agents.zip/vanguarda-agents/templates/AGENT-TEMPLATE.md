---
name: agt-XX-nome-curto
agent-id: AGT-XX
description: >
  Uma frase de missão + lista explícita de gatilhos em linguagem natural.
  A descrição é o que faz o agente disparar — escreva os gatilhos como as
  pessoas realmente falam, não como o manual descreve.
  Gatilhos: "...", "...", "...".
layer: 0|1|2|3|4
autonomy: N1|N2|N3
status: backlog|homologacao|piloto|producao|bloqueado
owner: Cargo responsável (A do RACI)
composes: [skill-1, skill-2]
connectors: [conector-1, conector-2]
blocked-by: (opcional) motivo do bloqueio
version: 1.0
---

# AGT-XX · NOME

## Missão
Uma frase. Qual dor operacional este agente elimina. Se não couber em uma frase,
o escopo do agente está errado.

## Pré-voo
O que precisa existir antes de rodar. Se faltar, **parar e perguntar** — nunca
inventar premissa.

## Fluxo
Passos numerados e executáveis. Cada passo diz o que consulta e o que produz.

## Entregável
Formato exato da saída. Se possível, mostrar o esqueleto.

## Gates
Quais aprovações são obrigatórias e quem aprova. Coerente com `governance/approval-gates.md`.

## KPI
2 a 4 indicadores com meta. Se não houver como medir, o agente não entra em produção.

## Falhas conhecidas
O que este agente erra ou não cobre. **Seção obrigatória.**
Agente sem falha declarada é agente não testado.
