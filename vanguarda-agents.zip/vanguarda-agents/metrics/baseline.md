# Baseline Operacional — INSTRUMENTO DE MEDIÇÃO

**Status:** ⚠ NÃO MEDIDO · **Prazo:** 2 semanas · **Dono:** PMO
**Criticidade:** BLOQUEANTE. Nenhuma meta vai ao Comitê antes disto.

## Por que isto vem antes de tudo
Todo percentual de ganho declarado no programa é **estimativa de ordem de grandeza**.
Se o Comitê aprovar sobre estimativa e a medição posterior mostrar número diferente,
o programa perde patrocínio — mesmo tendo funcionado.

Medir baseline não é burocracia. É blindagem política do programa.

## Como medir
Duas semanas corridas. Cada pessoa registra tempo real por atividade, sem estimar
no fim do dia. Ferramenta: apontamento no próprio gestor de tarefa ou planilha simples.

## Instrumento

| Processo | Quem executa | Freq. | Horas medidas (2 sem) | Horas/mês extrapolado | Agente-alvo |
|---|---|---|---|---|---|
| Relatório mensal de cliente | Atendimento + Dados | Mensal | | | AGT-09 |
| Otimização manual de mídia | Mídia | Diária | | | AGT-07 |
| Tráfego e cobrança de jobs | Traffic | Diária | | | AGT-12 |
| Montagem de proposta | Novos Negócios | Por concorrência | | | AGT-02 |
| Pesquisa pré-reunião | Novos Negócios | Por reunião | | | AGT-01 |
| Produção de peça social | Criação | Diária | | | AGT-05 |
| Elaboração de POP | Controladoria | Eventual | | | AGT-13 |
| Consolidação de dado / planilha | Diversos | Semanal | | | AGT-08 |

## Métrica crítica — só o AGT-12 produz
| Etapa | Aprovador | Tempo médio parado | Nº de jobs |
|---|---|---|---|
| Aprovação interna de arte | | | |
| Aprovação de texto | | | |
| Aprovação de cliente | | | |
| Aprovação do COO | | | |

> Se o tempo em fila de aprovação for maior que o tempo de produção, **a prioridade do
> programa muda**: destravar aprovação passa na frente de automatizar produção.

## Regra de uso
Célula vazia neste documento = **número não pode ser citado** em apresentação,
proposta ou reunião de Comitê. Sem exceção.
