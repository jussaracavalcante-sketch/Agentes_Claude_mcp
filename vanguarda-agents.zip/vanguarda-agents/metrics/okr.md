# OKR do Programa de Agentes

⚠ Valores-alvo são **provisórios** até `metrics/baseline.md` estar preenchido.

## O1 — Liberar capacidade produtiva
| KR | Meta | Fonte | Status |
|---|---|---|---|
| KR1.1 | Horas de relatoria −75% | AGT-09 vs. baseline | Aguarda baseline |
| KR1.2 | Horas de otimização manual de mídia −60% | AGT-07 vs. baseline | Aguarda baseline |
| KR1.3 | ≥60% da hora liberada vira hora faturável ou novo negócio | AGT-15 | Aguarda baseline |

> **KR1.3 é o que valida o programa.** Liberar hora sem realocá-la não gera valor —
> gera ociosidade. É também a métrica que sustenta a narrativa do AGT-14 CHANGE
> perante a equipe.

## O2 — Acelerar o ciclo de entrega
| KR | Meta | Fonte |
|---|---|---|
| KR2.1 | Lead time briefing → no ar ≤ 6 dias úteis | AGT-10 / AGT-12 |
| KR2.2 | ≥90% dos jobs no prazo | AGT-12 |
| KR2.3 | ≥70% das peças aprovadas na 1ª rodada | AGT-05 |

## O3 — Tornar a operação governável
| KR | Meta | Fonte |
|---|---|---|
| KR3.1 | 100% dos processos críticos com POP vigente | AGT-13 |
| KR3.2 | 100% dos clientes com margem visível mensalmente | AGT-15 |
| KR3.3 | Zero incidente de disparo não autorizado ou vazamento | Gates G1–G5 |

## O4 — Escalar sem escalar headcount
| KR | Meta | Fonte |
|---|---|---|
| KR4.1 | Receita por FTE +25% | AGT-15 |
| KR4.2 | ≥12 dos 17 agentes com uso semanal recorrente | Telemetria |
| KR4.3 | ≥3 novos agentes criados pela própria equipe | AGT-00 / skill-creator |

> **KR4.3 é o teste real de maturidade.** Enquanto só a liderança criar agentes,
> o programa é iniciativa. Quando a operação criar, virou capacidade instalada.
