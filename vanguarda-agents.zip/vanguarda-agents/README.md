# Repositório de Agentes — Vanguarda

Agentes operacionais da agência: **Vanguarda Martech · VPromo · VBOT**
Versão 1.0 · Agosto/2026 · Sponsor: COO · Classificação: Uso Interno

---

## O que é isto

Repositório versionado dos **17 agentes** que automatizam a operação da agência.
Cada agente é um arquivo `AGENT.md` com frontmatter YAML — mesmo formato das skills
instaladas, portanto **instalável e disparável**, não apenas documentação.

Este repositório é a fonte única de verdade sobre: o que cada agente faz, quem é o
dono, qual o nível de autonomia, quais aprovações são obrigatórias e como medir se
está funcionando.

---

## Estrutura

```
vanguarda-agents/
├── README.md               ← você está aqui
├── CATALOG.md              ← índice gerado (não editar à mão)
├── CONNECTORS.md           ← mapa de conectores e criticidade
├── CHANGELOG.md
├── build-catalog.py        ← regera o catálogo a partir do frontmatter
├── agents/                 ← 17 agentes (AGT-00 … AGT-16)
├── governance/             ← autonomia · gates · riscos · LGPD
├── templates/              ← template de agente · ficha de homologação
├── runbooks/               ← falha de conector · destravar Orchestra · fonte financeira
└── metrics/                ← baseline (a medir) · OKR
```

---

## Como ler um agente

Todo `AGENT.md` tem a mesma anatomia:

| Campo | Para quê |
|---|---|
| `agent-id` · `layer` | Identidade e posição na cadeia de valor |
| `autonomy` | N1 sugere · N2 executa com aprovação · N3 executa e loga |
| `status` | 🟢 produção · 🔵 piloto · 🟡 homologação · ⚪ backlog · 🔴 bloqueado |
| `owner` | O **A** do RACI. Agente sem dono não vai a produção |
| `composes` | Skills que ele orquestra |
| `connectors` | De onde puxa dado |
| `blocked-by` | Se bloqueado, o motivo explícito |

Corpo: **Missão · Pré-voo · Fluxo · Entregável · Gates · KPI · Falhas conhecidas**.

---

## Regras de entrada

Um agente só muda de status com estes requisitos atendidos:

1. **Dono nomeado** e ciente do accountability
2. **Nível de autonomia** declarado — N4 é vedado nesta fase
3. **Gates** coerentes com `governance/approval-gates.md`
4. **KPI mensurável** — sem métrica, não entra em produção
5. **Seção "Falhas conhecidas"** preenchida — agente sem falha declarada é agente não testado
6. **Ficha de homologação** assinada (`templates/ficha-homologacao.md`)

---

## Estado atual — leitura honesta

**17 agentes desenhados. 1 em produção. 3 bloqueados.**

Os três bloqueios não são técnicos:

| Agente | Bloqueio | Natureza |
|---|---|---|
| `AGT-06` CONTENT | Fonte financeira presume QuickBooks/PayPal; a casa usa iClips/Conexa | Integração |
| `AGT-10` ORCHESTRA | Invoca `content-strategy` e `lead-triage`, ausentes do inventário | Skill faltante |
| `AGT-14` CHANGE | A skill `change-management` está vazia (só um link externo) | Conteúdo faltante |

Três pré-requisitos da Onda 0 também seguem em aberto:
`metrics/baseline.md` (não medido) · `governance/lgpd-mapping.md` (não preenchido) ·
`metrics/glossario.md` (data-context-extractor não rodado).

> **Nenhum agente de camada 3 deve ir a produção antes do glossário de métricas.**
> Sem ele, o agente acerta a sintaxe e erra a semântica de negócio — o modo de falha
> mais caro, porque o número sai plausível e errado.

---

## Ordem de implantação

```
ONDA 0 · Fundação      baseline · LGPD · glossário · destravar bloqueios · gates aprovados
ONDA 1 · Quick value   AGT-07 · AGT-08 · AGT-09 · AGT-00 · AGT-12 · AGT-13
ONDA 2 · Escala        AGT-05 · AGT-06 · AGT-01 · AGT-02 · AGT-03 · AGT-04 · AGT-11 · AGT-14
ONDA 3 · Orquestração  AGT-10 · AGT-15 · AGT-16 · novos agentes via skill-creator
```

**Nada de Onda 1 entra antes da Onda 0 fechar.** Automatizar processo não mapeado
é industrializar o erro.

---

## Como criar um novo agente

1. Copiar `templates/AGENT-TEMPLATE.md` para `agents/AGT-XX-nome/AGENT.md`
2. Preencher frontmatter e corpo — **gatilhos em linguagem natural**, como as pessoas
   realmente falam. É a descrição que faz o agente disparar
3. Rodar `python3 build-catalog.py` para atualizar o índice
4. Preencher `templates/ficha-homologacao.md`
5. Aprovação do dono + COO → status `piloto`

O `AGT-00 COO COPILOT` carrega `skill-creator` justamente para que a operação crie
seus próprios agentes. **Quando a operação passar a criar agentes sozinha, o programa
deixou de ser iniciativa e virou capacidade instalada.**

---

## Advertência de método

Todos os alvos numéricos citados neste repositório são **estimativas de ordem de
grandeza** até `metrics/baseline.md` estar preenchido com medição real de duas semanas.

Célula vazia no baseline = número que **não pode ser citado** em Comitê, proposta ou
apresentação a cliente.

---

## Contatos de governança

| Papel | Responsável |
|---|---|
| Sponsor do programa | COO |
| Aprovador final de POP (SGQ) | Breno Maciel — CEO |
| Gestor de processos | Wilson Caldas Jr. — CFO |
| Revisor técnico SGQ | Thyago Molde — Supervisor Controladoria |
| LGPD | DPO / Jurídico — *a nomear* |
