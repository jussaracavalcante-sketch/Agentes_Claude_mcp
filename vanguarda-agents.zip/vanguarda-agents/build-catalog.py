#!/usr/bin/env python3
"""Gera CATALOG.md a partir do frontmatter dos agentes. Fonte unica de verdade."""
import glob, re, os

STATUS_ICON = {"producao":"🟢","piloto":"🔵","homologacao":"🟡","backlog":"⚪","bloqueado":"🔴"}
STATUS_LABEL = {"producao":"Produção","piloto":"Piloto","homologacao":"Homologação",
                "backlog":"Backlog","bloqueado":"BLOQUEADO"}
LAYER = {"0":"Orquestração","1":"Front Office","2":"Delivery",
         "3":"Inteligência","4":"Governança & Backoffice"}

def parse(path):
    txt = open(path, encoding="utf-8").read()
    fm = txt.split("---")[1]
    d = {}
    for key in ["agent-id","layer","autonomy","status","owner","composes","connectors","blocked-by"]:
        m = re.search(rf"^{key}:\s*(.+)$", fm, re.M)
        d[key] = m.group(1).strip() if m else ""
    m = re.search(r"^# (AGT-\S+ · .+)$", txt, re.M)
    d["title"] = m.group(1) if m else ""
    d["name"] = d["title"].split("·")[-1].strip() if d["title"] else ""
    d["path"] = os.path.relpath(path)
    d["n_skills"] = len([s for s in d["composes"].strip("[]").split(",") if s.strip()])
    return d

rows = sorted((parse(p) for p in glob.glob("agents/*/AGENT.md")), key=lambda r: r["agent-id"])

out = ["# Catálogo de Agentes", "",
       "> Gerado por `build-catalog.py`. **Não editar à mão** — editar o frontmatter do agente e regerar.", ""]

tot = len(rows)
by_status = {}
for r in rows: by_status[r["status"]] = by_status.get(r["status"], 0) + 1
out += [f"**{tot} agentes** · " + " · ".join(
    f"{STATUS_ICON.get(s,'')} {STATUS_LABEL.get(s,s)}: {n}"
    for s, n in sorted(by_status.items(), key=lambda x: -x[1])), ""]

out += ["| ID | Agente | Camada | Autonomia | Status | Dono | Skills |",
        "|---|---|---|---|---|---|---|"]
for r in rows:
    st = f"{STATUS_ICON.get(r['status'],'')} {STATUS_LABEL.get(r['status'], r['status'])}"
    out.append(f"| [`{r['agent-id']}`]({r['path']}) | {r['name']} | {LAYER.get(r['layer'],r['layer'])} "
               f"| {r['autonomy']} | {st} | {r['owner']} | {r['n_skills']} |")

blocked = [r for r in rows if r["status"] == "bloqueado"]
if blocked:
    out += ["", "## 🔴 Agentes bloqueados — não vão a produção", "",
            "| ID | Agente | Bloqueio | Runbook |", "|---|---|---|---|"]
    rb = {"AGT-06":"runbooks/mapeamento-fonte-financeira.md",
          "AGT-10":"runbooks/destravar-orchestra.md",
          "AGT-14":"—"}
    for r in blocked:
        out.append(f"| `{r['agent-id']}` | {r['name']} | `{r['blocked-by']}` | {rb.get(r['agent-id'],'—')} |")

out += ["", "## Distribuição por camada", "", "| Camada | Agentes |", "|---|---|"]
for lk in sorted(LAYER):
    ids = [r["agent-id"] for r in rows if r["layer"] == lk]
    if ids: out.append(f"| {lk} — {LAYER[lk]} | {' · '.join(ids)} |")

open("CATALOG.md","w",encoding="utf-8").write("\n".join(out) + "\n")
print(f"CATALOG.md gerado — {tot} agentes")
for s,n in sorted(by_status.items()): print(f"  {STATUS_ICON.get(s,'')} {s}: {n}")
