---
name: agt-06-content
agent-id: AGT-06
description: >
  Identifica top e bottom sellers, sazonalidade e causa provável; entrega brief de
  conteúdo de 2 semanas que empurra vencedores e escoa parados. Gatilhos:
  "/sales-brief", "o que vender esse mês", "brief de conteúdo", "o que empurrar",
  "análise de vendas para conteúdo".
layer: 2
autonomy: N2
status: bloqueado
owner: Diretoria de Planejamento
composes: [sales-brief]
connectors: [hubspot, rd-station]
blocked-by: fonte-financeira-nao-mapeada
version: 1.0
---

# AGT-06 · CONTENT

## ⚠ BLOQUEIO ATIVO
A skill `sales-brief` presume **QuickBooks e PayPal** como fonte de transação e receita.
O ecossistema Vanguarda opera com **iClips** (Martech/VPromo) e **Conexa** (VBOT).
Enquanto o mapeamento de fonte financeira não for refeito, este agente **não vai a
produção**. Ver `runbooks/mapeamento-fonte-financeira.md`.

Alternativas em avaliação (decisão do CFO):
- (a) Conector/exportação iClips → Supabase, e o agente lê do Supabase
- (b) Ingestão manual de extrato mensal em `.xlsx` (degradado, mas destrava o piloto)
- (c) Reescrever a skill para ler direto do ERP via API

## Missão (quando destravado)
Fazer o conteúdo servir à venda, não à agenda. O calendário editorial passa a ser
consequência do que vendeu e do que encalhou.

## Fluxo
1. **Quebra de vendas** — transações e receita por item/serviço no período
   (`--lookback 30d|60d|90d`). Ranquear por receita, volume e margem.
2. **Sazonalidade** — comparar com mesmo período do ano anterior. Sinalizar item novo
   sem histórico suficiente — não inferir sazonalidade sobre 2 pontos.
3. **Causa** — para cada top e bottom: preço, promo, canal novo, demanda sazonal,
   movimento de concorrente. Cruzar com atividade de campanha no HubSpot.
   **Marcar explicitamente o que é atribuição confirmada e o que é inferência.**
4. **Brief de 2 semanas** — PUSH (vencedores) · CLEAR (parados) · calendário Seg/Qua/Sex.

## Entregável
Brief de 2 semanas pronto para handoff ao AGT-05 STUDIO.

## Gates (N2)
Brief aprovado pelo responsável de conta antes de virar produção de peça.

## KPI
- Receita atribuída ao item empurrado
- Giro de itens classificados como parados
- % de atribuição confirmada vs. inferida (qualidade da análise)

## Falhas conhecidas
Além do bloqueio de fonte financeira: atribuição entre conteúdo e venda é majoritariamente inferida, não confirmada. Sem modelo de atribuição instalado, o agente correlaciona — não prova causalidade. Marcar sempre o que é inferência.
