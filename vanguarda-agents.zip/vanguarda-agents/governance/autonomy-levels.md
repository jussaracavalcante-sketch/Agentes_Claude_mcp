# Política de Níveis de Autonomia

**Status:** aguardando aprovação do Comitê Executivo
**Regra de entrada:** nenhum agente vai a produção sem nível declarado no frontmatter.

| Nível | Nome | Comportamento | Aplicação típica |
|---|---|---|---|
| **N1** | Assistivo | Analisa e sugere. Humano executa 100% | Ação irreversível, financeira ou de marca |
| **N2** | Supervisionado | Prepara e faz *staging*. Executa só com "aprovado" explícito | **Padrão da agência** |
| **N3** | Autônomo auditado | Executa e registra log; auditoria por amostragem | Leitura, síntese, alerta |
| **N4** | Autônomo pleno | Executa sem revisão | **VEDADO NESTA FASE** |

## Distribuição atual

| Nível | Agentes |
|---|---|
| N1 | AGT-07 MEDIA OPS · AGT-15 VALUE |
| N2 | AGT-02 · AGT-03 · AGT-05 · AGT-06 · AGT-09 · AGT-10 · AGT-11 · AGT-13 · AGT-14 · AGT-16 |
| N3 | AGT-00 · AGT-01 · AGT-04 · AGT-08 · AGT-12 |
| N4 | — (vedado) |

## Critério de rebaixamento
Qualquer agente **cai um nível automaticamente** e é suspenso para revisão se ocorrer:
- Número incorreto publicado a cliente ou ao Comitê
- Ação executada sem aprovação registrada
- Exposição de dado pessoal fora da base legal mapeada

Retorno ao nível anterior exige análise de causa raiz documentada e aprovação do dono.
