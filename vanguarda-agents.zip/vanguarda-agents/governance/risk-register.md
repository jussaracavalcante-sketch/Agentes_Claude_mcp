# Registro de Riscos do Programa

Escala: P = probabilidade (B/M/A) · I = impacto (Baixo/Médio/Alto/Crítico)

| ID | Risco | P | I | Exposição | Mitigação | Dono | Status |
|---|---|---|---|---|---|---|---|
| R1 | Disparo indevido a base de cliente | M | Crítico | **Alta** | Gate G1; comando nominal; sandbox no piloto | Dir. Atendimento | Aberto |
| R2 | Alucinação de número em relatório de cliente | M | Crítico | **Alta** | `data:validate-data` obrigatório; revisão humana; glossário via data-context-extractor | Head de Dados | Aberto |
| R3 | AGT-10 quebra por skills ausentes | A | Alto | **Alta** | Onda 0: implementar ou redesenhar. Agente marcado `bloqueado` | COO | **Ativo** |
| R4 | Exposição de dado pessoal / LGPD | M | Crítico | **Alta** | Gate G5; mapa de base legal; DPA; registro de tratamento | DPO / Jurídico | Aberto |
| R5 | Queda ou revogação de conector | A | Médio | Média | Gate G4; health-check diário; runbook de fallback | Head de Dados | Aberto |
| R6 | Brand safety — peça fora do manual | M | Alto | Média | Aprovação peça a peça; brand kit travado no Canva | Dir. Criação | Aberto |
| R7 | Rejeição da equipe ("a IA vai me substituir") | A | Alto | **Alta** | AGT-14 CHANGE; narrativa de reposicionamento; métrica de hora realocada | COO / RH | **Ativo** |
| R8 | Dependência de pessoa-chave no SGQ | M | Alto | Média | POP do próprio programa gerado pelo AGT-13 | CFO | Aberto |
| R9 | Custo de token/geração acima do previsto | M | Médio | Média | Teto mensal por agente; telemetria; orçamento de geração no AGT-05 | COO | Aberto |
| R10 | `change-management` vazia compromete adoção | A | Médio | Média | Implementar na Onda 0 ou substituir por ADKAR/Kotter | COO | **Ativo** |
| R11 | Fonte financeira não mapeada (iClips/Conexa) | A | Alto | **Alta** | Runbook de mapeamento; bloqueia AGT-06 e AGT-10 | CFO | **Ativo** |
| R12 | Gargalo de aprovação anula ganho de produção | A | Alto | **Alta** | AGT-12 mede tempo em fila; destravar antes da Onda 2 | COO | **Ativo** |

## Leitura executiva
Os cinco riscos **ativos** — R3, R7, R10, R11, R12 — não são técnicos.
Quatro são de processo e um é de gente. Este padrão é esperado e deve ser dito ao
Comitê sem suavização: **este programa não falha por tecnologia.**
