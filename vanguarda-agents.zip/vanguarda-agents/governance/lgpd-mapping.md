# Mapa LGPD por Conector — TEMPLATE A PREENCHER

**Status:** ⚠ NÃO PREENCHIDO — pré-requisito bloqueante da Onda 0
**Responsável:** DPO / Jurídico · **Prazo:** D+30

Nenhum agente que trate dado pessoal vai a produção antes deste documento preenchido
e homologado pelo Jurídico.

| Conector | Dado pessoal tratado | Titular | Base legal (art. 7º) | Finalidade | Retenção | Agente |
|---|---|---|---|---|---|---|
| HubSpot | nome, e-mail, telefone, comportamento | Contato do cliente | *a definir* | *a definir* | *a definir* | AGT-01, 05, 06, 09, 10 |
| RD Station | nome, e-mail, comportamento | Lead | *a definir* | *a definir* | *a definir* | AGT-06, 09 |
| Intercom | conversa, identificador | Usuário final | *a definir* | *a definir* | *a definir* | AGT-04, 16 |
| Google Ads | agregado (sem PII direta) | — | Legítimo interesse* | Otimização | — | AGT-07, 09 |
| Meta Ads | agregado (sem PII direta) | — | Legítimo interesse* | Otimização | — | AGT-07, 09 |
| Gmail | conteúdo de e-mail corporativo | Colaborador / cliente | *a definir* | *a definir* | *a definir* | AGT-00, 12, 14 |
| Supabase | conforme modelagem | *a definir* | *a definir* | *a definir* | *a definir* | AGT-08, 15 |
| Asana/monday/Jira | nome de colaborador, alocação | Colaborador | *a definir* | *a definir* | *a definir* | AGT-11, 12 |

\* Legítimo interesse exige **teste de balanceamento documentado**. Verificar com Jurídico.

## Perguntas a responder antes de liberar
1. Há DPA (acordo de tratamento) assinado com cada fornecedor de conector?
2. O dado sai do território nacional? Se sim, há cláusula de transferência internacional?
3. O registro de operações de tratamento (art. 37) foi atualizado incluindo os agentes?
4. Como o titular exerce direito de eliminação sobre dado que já passou por prompt?
5. Há retenção de prompt e log pelo fornecedor de IA? Por quanto tempo?

> **A pergunta 5 é a mais esquecida e a mais difícil de remediar depois.**
