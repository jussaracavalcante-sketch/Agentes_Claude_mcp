# Gates de Aprovação — Regras Duras

Estas cinco regras não admitem exceção operacional. Alteração só por decisão do
Comitê Executivo, registrada em ata.

## G1 — Disparo a base
Nenhum envio a base de cliente (HubSpot, RD Station, e-mail marketing) sem
**aprovação nominal e registrada** do responsável de conta.
*Agentes afetados:* AGT-05, AGT-06, AGT-09, AGT-10

## G2 — Conta de mídia
Nenhuma alteração de budget, lance, status ou segmentação executada por agente.
Conectores de mídia operam em leitura. O agente aponta; o analista age e registra.
*Agentes afetados:* AGT-07

## G3 — Publicação de peça
Nenhuma peça publicada sem aprovação de arte **e** de cliente registradas.
Tudo permanece *staged*.
*Agentes afetados:* AGT-05, AGT-10

## G4 — Falha de conector
Conector inacessível = **parada imediata**, com reporte de qual conector caiu e
pergunta explícita ao humano: repetir ou abortar.
**Proibido completar lacuna com estimativa.** Especialmente em relatório de cliente.
*Agentes afetados:* todos

## G5 — Dado pessoal
Nenhum dado pessoal trafega em prompt sem base legal LGPD mapeada em
`governance/lgpd-mapping.md`. Verbatim de pessoa física entra anonimizado.
*Agentes afetados:* AGT-01, AGT-04, AGT-09, AGT-10

---

## Registro de exceção
Toda exceção a um gate deve ser registrada em `governance/excecoes.log` com:
data · agente · gate · justificativa · autorizador · resultado.
**Exceção não registrada é incidente, não exceção.**
